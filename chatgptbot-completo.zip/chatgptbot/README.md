# Discord Sales Bot

Bot de vendas digitais para Discord com loja, pedidos, Pix, painel administrativo e entrega automática por DM.

## Stack
Node.js, discord.js, Supabase PostgreSQL e Express.

## Configuração
1. Execute `supabase/schema.sql` no SQL Editor do Supabase.
2. Edite os 4 links de exemplo da tabela `products`.
3. Copie `.env.example` para `.env` e preencha as variáveis.
4. Rode `npm install` e `npm start`.

## Variáveis
`DISCORD_TOKEN`, `DISCORD_CLIENT_ID`, `DISCORD_GUILD_ID`, `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `ADMIN_ROLE_ID` ou `ADMIN_USER_ID`, `PIX_KEY`, `PIX_NAME` e `PORT`.

Nunca publique `DISCORD_TOKEN` ou `SUPABASE_SERVICE_ROLE_KEY`.

## Comandos
- `/loja`: mostra produtos e botões de compra.
- `/pedido CODIGO`: consulta o próprio pedido.
- `/painel`: mostra pedidos pendentes/pagos para administradores.

## Fluxo
Cliente compra -> pedido é criado -> bot mostra Pix -> administrador confere o pagamento -> aprova no painel -> bot envia os links por DM.

A confirmação de Pix desta versão é manual. Confirmação automática exige API de pagamento compatível e credenciais do provedor.
